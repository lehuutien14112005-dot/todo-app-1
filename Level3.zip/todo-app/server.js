const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const session = require("express-session");
require("./db");

const taskRoutes = require("./routes/taskRoutes");
const userRoutes = require("./routes/userRoutes");

const app = express();

// View engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

// Session
app.use(session({
  secret: "secret123",
  resave: false,
  saveUninitialized: true
}));

// Routes
app.use("/", userRoutes);
app.use("/tasks", taskRoutes);

// Home
app.get("/", (req, res) => {
  res.redirect("/login");
});

app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
