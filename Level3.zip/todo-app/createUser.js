const mongoose = require("mongoose");
const User = require("./models/User");

mongoose.connect("mongodb://127.0.0.1:27017/todoapp");

async function run() {
  await User.create({ username: "admin", password: "123", role: "admin" });
  await User.create({ username: "tien", password: "123", role: "normal" });
  await User.create({ username: "nam", password: "123", role: "normal" });

  console.log("Đã tạo user");
  process.exit();
}

run();
