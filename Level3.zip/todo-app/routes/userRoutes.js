const express = require("express");
const User = require("../models/User");
const router = express.Router();

// Login page
router.get("/login", (req, res) => {
  res.render("login");
});

// Login submit
router.post("/login", async (req, res) => {
  const { username, password } = req.body;

  const user = await User.findOne({ username, password });
  if (!user) return res.send("Sai tài khoản");

  req.session.user = user;
  res.redirect("/tasks");
});

module.exports = router;
