const express = require("express");
const router = express.Router();
const Task = require("../models/Task");
const User = require("../models/User");

// Middleware login
function isLogin(req, res, next) {
  if (!req.session.user) return res.redirect("/login");
  next();
}

// Middleware admin
function isAdmin(req, res, next) {
  if (req.session.user.role !== "admin") {
    return res.send("Bạn không phải admin");
  }
  next();
}

// ========== LIST TASK ==========
router.get("/", isLogin, async (req, res) => {
  const tasks = await Task.find()
    .populate("assignedTo")
    .populate("doneBy");

  const users = await User.find();

  res.render("tasks", {
    tasks,
    users,
    user: req.session.user
  });
});

// ========== CREATE TASK ==========
router.post("/", isLogin, async (req, res) => {
  const task = new Task({
    title: req.body.title,
    assignedTo: [req.session.user._id]
  });

  await task.save();
  res.redirect("/tasks");
});

// ========== ADMIN ASSIGN TASK ==========
router.post("/assign/:id", isLogin, isAdmin, async (req, res) => {
  const { userId } = req.body;

  const task = await Task.findById(req.params.id);

  if (!task.assignedTo.includes(userId)) {
    task.assignedTo.push(userId);
  }

  await task.save();
  res.redirect("/tasks");
});

// ========== USER DONE TASK ==========
router.post("/done/:id", isLogin, async (req, res) => {
  const task = await Task.findById(req.params.id);
  const userId = req.session.user._id.toString();

  // add doneBy
  if (!task.doneBy.map(id => id.toString()).includes(userId)) {
    task.doneBy.push(userId);
  }

  // nếu tất cả user assigned đã done
  if (task.doneBy.length === task.assignedTo.length) {
    task.done = true;
    task.doneAt = new Date();
  }

  await task.save();
  res.redirect("/tasks");
});

// ========== DELETE ==========
router.post("/delete/:id", isLogin, async (req, res) => {
  await Task.findByIdAndDelete(req.params.id);
  res.redirect("/tasks");
});

module.exports = router;
