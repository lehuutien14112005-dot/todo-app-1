const mongoose = require("mongoose");

const TaskSchema = new mongoose.Schema({
  title: String,

  assignedTo: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
  }],

  doneBy: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
  }],

  done: {
    type: Boolean,
    default: false
  },

  doneAt: Date
});

module.exports = mongoose.model("Task", TaskSchema);
